import './js/libs/weapp-adapter'
import './js/libs/symbol'

import Main from './js/demo2/main'

new Main()
